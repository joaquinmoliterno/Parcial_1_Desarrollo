#!/bin/bash
source $HOME/environments/gral/bin/activate
pip3 install -r requirements.txt
